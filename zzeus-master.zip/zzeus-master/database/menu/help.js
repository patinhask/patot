const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511934660977
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


❍ 𝙻𝙸𝙼𝙸𝚃𝙴 

  ║➩ ❍ ${prefix}limite (ver seu limite)
  ║➩ ❍ ${prefix}buylimite (comprar limite)
  ║➩ ❍ ${prefix}bal (ver seu dinheiro)
  ║➩ Aumente seu level interagindo no grupo!!

  ║➩ ❍ ${prefix}
❍ 𝚂𝙾𝙱𝚁𝙴
  
  ║➩ ❍ ${prefix}info
  ║➩ ❍ ${prefix}blocklist
  ║➩ ❍ ${prefix}chatlist
  ║➩ ❍ ${prefix}ping
  ║➩ ❍ ${prefix}bugreport
❍ 𝙵𝙰𝚉𝙴𝚁
  
  ║➩ ❍ ${prefix}figu
  ║➩ ❍ ${prefix}toimg
  ║➩ ❍ ${prefix}virarmp3
  ║➩ ❍ ${prefix}shadow
  ║➩ ❍ ${prefix}burnpaper
  ║➩ ❍ ${prefix}coffee
  ║➩ ❍ ${prefix}lovepaper
  ║➩ ❍ ${prefix}calunia
  ║➩ ❍ ${prefix}shota
❍ 𝙼𝙴𝙳𝙸𝙰
  
  ║➩ ❍ ${prefix}trendtwit
  ║➩ ❍ ${prefix}randomkpop
  ║➩ ❍ ${prefix}ytsearch
❍ 𝙵𝙰𝙻𝙰𝙻𝙰𝚁 𝙲𝙾𝙼 𝙱𝙾𝚃
  
  ║➩ ❍ ${prefix}avalie
❍ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳
  
  ║➩ ❍ ${prefix}images
  ║➩ ❍ ${prefix}ytmp3
  ║➩ ❍ ${prefix}ytmp4
  ║➩ ❍ ${prefix}tiktok
  ║➩ ❍ ${prefix}joox
❍ 𝙼𝙴𝙼𝙴
  
  ║➩ ❍ ${prefix}meme
  ║➩ ❍ ${prefix}memeindo
❍ 𝚂𝙾𝙼
  
  ║➩ ❍ ${prefix}musica
  ║➩ ❍ ${prefix}audio
❍ 𝙼𝚄𝚂𝙸𝙲𝙰
  
  ║➩ ❍ ${prefix}lirik
  ║➩ ❍ ${prefix}chord
❍ 𝚂𝚃𝙰𝙻𝙺𝙴𝙰𝚁
  
  ║➩ ❍ ${prefix}tiktokstalk
  ║➩ ❍ ${prefix}igstalk
❍ 𝙰𝙽𝙸𝙼𝙴𝚂
  
  ║➩ ❍ ${prefix}neonime
  ║➩ ❍ ${prefix}pokemon
  ║➩ ❍ ${prefix}loli
  ║➩ ❍ ${prefix}waifu
  ║➩ ❍ ${prefix}randomanime
  ║➩ ❍ ${prefix}husbu
  ║➩ ❍ ${prefix}husbu2
  ║➩ ❍ ${prefix}buscanime
  ║➩ ❍ ${prefix}nekonime
❍ 𝙲𝙾𝙼𝙰𝙽𝙳𝙾𝚂 𝙳𝙴 𝙰𝚄𝙳𝙸𝙾
  
  ║➩ ❍ ${prefix}bahasa
❍ 𝙳𝙾𝙽𝙾
  
  ║➩ ❍ ${prefix}setprefix
  ║➩ ❍ ${prefix}block
  ║➩ ❍ ${prefix}tm
  ║➩ ❍ ${prefix}tmctt
  ║➩ ❍ ${prefix}clone
  ║➩ ❍ ${prefix}clearall
❍ 𝙾𝚄𝚃𝚁𝙾𝚂
 
  ║➩ ❍ ${prefix}send
  ║➩ ❍ ${prefix}wame
  ║➩ ❍ ${prefix}virtex
  ║➩ ❍ ${prefix}exe
  ║➩ ❍ ${prefix}qrcode
  ║➩ ❍ ${prefix}afk
  ║➩ ❍ ${prefix}timer
  ║➩ ❍ ${prefix}fml
  ║➩ ❍ ${prefix}fml2
  ❍𝙼𝙴𝙽𝚄 𝙰𝙳𝙼𝙸𝙽
  
 ║➩ ❍ ${prefix}abrirgp
 ║➩ ❍ ${prefix}fechargp
 ║➩ ❍ ${prefix}setname
 ║➩ ❍ ${prefix}setdesc
 ║➩ ❍ ${prefix}promover
 ║➩ ❍ ${prefix}rebaixar
 ║➩ ❍ ${prefix}marcar
 ║➩ ❍ ${prefix}marcar2
 ║➩ ❍ ${prefix}marcar3
 ║➩ ❍ ${prefix}marcar4
 ║➩ ❍ ${prefix}marcar5
 ║➩ ❍ ${prefix}add
 ║➩ ❍ ${prefix}remover
 ║➩ ❍ ${prefix}listadmins
 ║➩ ❍ ${prefix}linkgp
 ║➩ ❍ ${prefix}sairgp
 ║➩ ❍ ${prefix}bv
 ║➩ ❍ ${prefix}nsfw
 ║➩ ❍ ${prefix}leveling
 ║➩ ❍ ${prefix}level
 ║➩ ❍ ${prefix}apagar
 ║➩ ❍ ${prefix}simih
❍ 𝙼𝙴𝙽𝚄 𝙽𝚂𝙵𝚆
 
  ║➩ ❍ ${prefix}nsfwbobs
  ║➩ ❍ ${prefix}randomhentai
  ║➩ ❍ ${prefix}nsfwtrap
  ║➩ ❍ ${prefix}nsfwass
  ║➩ ❍ ${prefix}nsfwbelly
  ║➩ ❍ ${prefix}nsfwsidebobs
  ║➩ ❍ ${prefix}nsfwahegao
  ║➩ ❍ ${prefix}nsfwthighs
  ║➩ ❍ ${prefix}nsfwarmpits
  ║➩ ❍ ${prefix}nsfwfeets
`
}
exports.help = help
