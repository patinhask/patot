const kerang = (pushname, prefix, botName, ownerName) => {
	return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511934660977
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}apakah*
║➩ ❍ *${prefix}kapankah*
║➩ ❍ *${prefix}rate*
║➩ ❍ *${prefix}bisakah*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.kerang = kerang
