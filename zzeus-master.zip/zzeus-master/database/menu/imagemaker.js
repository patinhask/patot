const imagemaker = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511934660977
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}bpink*
║➩ ❍ *${prefix}snowwrite*
║➩ ❍ *${prefix}3dtext*
║➩ ❍ *${prefix}goldbutton*
║➩ ❍ *${prefix}tahta*
║➩ ❍ *${prefix}firetext*
║➩ ❍ *${prefix}glitch*
║➩ ❍ *${prefix}shadow*
║➩ ❍ *${prefix}burnpaper*
║➩ ❍ *${prefix}coffee*
║➩ ❍ *${prefix}lovepaper*
║➩ ❍ *${prefix}woodblock*
║➩ ❍ *${prefix}qowheart*
║➩ ❍ *${prefix}mutgrass*
║➩ ❍ *${prefix}undergocean*
║➩ ❍ *${prefix}woodenboards*
║➩ ❍ *${prefix}wolfmetal*
║➩ ❍ *${prefix}metalictglow*
║➩ ❍ *${prefix}8bit*
║➩ ❍ *${prefix}herrypotter*
║➩ ❍ *${prefix}quotemaker*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.imagemaker = imagemaker
